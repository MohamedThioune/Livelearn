
<!-- <!doctype html> -->
<?php
require __DIR__ . "/vendor/autoload.php";
use Goutte\Client;

function scraper($uri_root,$uri,$tag,$tag_children,$title,$content){
    
    $client = new Client();
    $out = null;
    
    //First passage
    $crawler = $client->request('GET',$uri);
    $articles = $crawler->filter($tag)->each(function($node) use ($out,$title,$uri){
        $articles = array();
        $article  = array();
        $url = $node->attr('href');
        $summary = trim($node->filter($title)->text());

        if(isset($uri_root)){
            $url = $uri_root . $url;
        }

        $article['title'] = $summary; 
        $article['url'] = $url; 

        array_push($articles, $article);

        return $articles;
    });

    //Second passage
    foreach($articles as $article){
        $uri = $article[0]['url'];
        //print_r ($uri.'</br>');
        $crawler = $client->request('GET', $uri);
        $long_text = '';
        $article['content'] = $crawler->filter($tag_children)->each(function($node) use ($out,$content,$long_text){
            $i=0;
            $intent = '';
            $pass = false;
            while($i <= 10){ 
                
                $latest_text = '';
                try{
                    $long_text = trim($node->filter($content)->eq($i)->text());
                    $intent .= "<br/>" . $long_text;
                    if($latest_text == $long_text){
                        echo "</br>";
                    }
                    $latest_text = $long_text;
                } catch(Exception $e) { // I guess its InvalidArgumentException in this case
                    // Node list is empty
                    $pass = true;
                }
                $i++;

                
            }
            echo "</br>";
            return $intent;
        });

        // print_r($article['title']);
        echo "<br>";
        print_r($article['content']);
    }

}

    scraper("https://www.nvab.nl/", "https://www.nvab.nl/nieuws","div.newsitem > a", "div.newsitem", ".title", ".news-link > p" );
    // scraper("https://www.nedverbak.nl/", "https://www.nedverbak.nl/nieuws","div.elementor-widget-container > a", "div.elementor-post__card", "div.elementor-post__title", "div.elementor-post__excerpt > p" );
    // scraper("https://www.nvab.nl/", "https://www.nvab.nl/nieuws","div.newsitem > a", "div.newsitem", ".title", ".news-link > p" );
?>