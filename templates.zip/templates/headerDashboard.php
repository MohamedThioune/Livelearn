<?php get_header(); ?>

<!-- 
<nav class="navbar navbar-expand-lg navbar-dark headerdashboard">
    <div class="container-fluid">
        <a class="navbar-brand navBrand" href="/">
            <div class="logoModife">
                  <img  src="img/logo.png" alt="">
            </div>
        </a>
       <div>
           <a href="#" class="nav-link navModife4 btn dropdown-toggle " type="button" id="dropdownNavButton1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               Dashboards <img class="imgArrowDropDown" src="img/down-chevron.svg" alt="">
           </a>
           <div class="dropdown-menu dropdown-menu-dashboard" aria-labelledby="dropdownMenuButton1">
               <a class="dropdown-item" href="#">Eigen leeromgeving</a>
               <a class="dropdown-item" href="#">Manager <span>intern</span></a>
               <a class="dropdown-item" href="#">Something else here <span>Extern</span></a>
           </div>
       </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item" href="#">
                    <button class="btn bntNotification">
                        <img src="img/notification.svg" alt="">
                    </button>
                </li>
                <li class="nav-item item4 dropdown">
                    <a href="#" class="nav-link navModife4 btn dropdown-toggle" type="button" id="dropdownNavButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img class="userBlockNav" src="img/adduser.png" alt="">
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav> 
-->