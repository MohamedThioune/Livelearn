<?php /** Template Name: Reaction Artikel */ ?>

<?php 
    extract($_POST);
?>